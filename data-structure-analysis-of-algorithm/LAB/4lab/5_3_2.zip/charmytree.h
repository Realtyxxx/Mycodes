#ifndef _MYTREE_
#define _MYTREE_

class myNode {
 private:
  void operator=(const myNode&) {}
  myNode(const myNode&) {}

 public:
  char E;
  myNode* left;
  myNode* right;
  myNode(char);
  ~myNode(){};
  myNode(char e, myNode* r, myNode* l);
  char getValue();
  void setValue(char);
  myNode* getLeft();
  myNode* getRight();
  void setLeft(myNode* l);
  void setRight(myNode* r);
};

#endif