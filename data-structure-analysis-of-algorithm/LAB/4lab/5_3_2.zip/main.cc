#include <iostream>
#include <stack>
#include <string>

#include "_charmytree.h"
using namespace std;

myNode* makeTree(string s);
bool contain(myNode* n1, myNode* n2);
bool equal(myNode* n1, myNode* n2);
// void printTree(myNode* root);
// void printTree(myNode* root, int level);

int main() {
  string s1;
  string s2;
  cin >> s1 >> s2;
  myNode* node1 = makeTree(s1);
  myNode* node2 = makeTree(s2);
  if (contain(node1, node2))
    cout << "yes";
  else
    cout << "no";
  return 0;
}

myNode* makeTree(string s) {
  // cout << "in " << s << endl;

  myNode* root = new myNode(s[0]);
  stack<myNode*> myq;
  myq.push(root);
  myNode* prev = myq.top()->left;
  for (int i = 1; i < s.length(); i++) {
    if (s[i] != '#') {
      prev = new myNode(s[i]);
      myq.push(prev);
      prev = prev->left;
    } else if (s[i] == '#') {
      if (s[i - 1] == '#') {
        if (i > 2 && (s[i - 2] != '#')) {
          myq.pop();
        }
        prev = myq.top()->right;
      } else if (s[i - 1] != '#') {
        prev = myq.top()->right;
      }
    }
  }
  // cout << "ok " << s << endl << endl;
  return root;
}

bool contain(myNode* node1, myNode* node2) {
  if (node1 == nullptr) return false;
  if (node1->E == node2->E) return equal(node1, node2);
  return contain(node1->left, node2) || contain(node1->right, node2);
}

bool equal(myNode* node1, myNode* node2) {
  if (node1 == nullptr && node2 == nullptr)
    return true;
  else if (node1 == nullptr || node2 == nullptr)
    return false;
  return (node1->getValue() == node2->getValue()) &&
         equal(node1->left, node2->left) &&
         equal(node1->right, node2->right);
}

// void printTree(myNode* root) { printTree(root, 0); }
// void printTree(myNode* root, int level) {
//   cout << (' ' * (8 - level));
//   if (root != nullptr) cout << root->E;
//   cout << endl;
//   if (root->left) {
//     printTree(root->left, level + 1);
//   }
//   if (root->right) {
//     printTree(root->left, level - 1);
//   }
// }