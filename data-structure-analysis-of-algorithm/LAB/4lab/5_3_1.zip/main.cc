#include <iostream>
#include <stack>
#include <string>

#include "_charmytree.h"
using namespace std;

myNode* makeTree(string s);
bool contain(myNode* n1, myNode* n2);

int main() {
  string s1;
  string s2;
  cin >> s1 >> s2;
  myNode* node1 = makeTree(s1);
  myNode* node2 = makeTree(s2);
  if (contain(node1, node2))
    cout << "yes";
  else
    cout << "no";
  return 0;
}

myNode* makeTree(string s) {

  // cout << "in " << s << endl;

  myNode* root = new myNode(s[0]);
  stack<myNode*> myq;
  myq.push(root);
  myNode* prev = myq.top()->left;
  for (int i = 1; i < s.length(); i++) {
    if (s[i] != '#') {
      prev = new myNode(s[i]);
      myq.push(prev);
      prev = prev->left;
    } else if (s[i] == '#') {
      if (s[i - 1] == '#') {
        if (i > 2 && (s[i - 2] != '#')) {
          myq.pop();
        }
        prev = myq.top()->right;
      } else if (s[i - 1] != '#') {
        prev = myq.top()->right;
      }
    }
  }
  // cout << "ok " << s << endl << endl;
  return root;
}

bool contain(myNode* node1, myNode* node2) {
  if (node1 == nullptr && node2 == nullptr)
    return true;
  else if (node1 == nullptr | node2 == nullptr)
    return false;
  return (node1->getValue() == node2->getValue()) &&
         contain(node1->getLeft(), node2->getLeft()) &&
         contain(node1->getRight(), node2->getRight());
}