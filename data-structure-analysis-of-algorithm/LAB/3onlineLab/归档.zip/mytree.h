#ifndef _MYTREE_
#define _MYTREE_

class myNode {
 private:
  void operator=(const myNode&) {}
  myNode(const myNode&) {}

 public:
  myNode* left;
  myNode* right;
  int E;
  myNode(int);
  ~myNode(){};
  myNode(int e, myNode* r, myNode* l);
  int getValue();
  myNode* getLeft(myNode* node);
  myNode* getRight(myNode* node);
  void setLeft(myNode* node, myNode* l);
  void setRight(myNode* node, myNode* r);
};

#endif