#include <assert.h>

#include "mytree.h"

myNode::myNode(int val) : E(val), left(nullptr), right(nullptr){};
myNode::myNode(int e, myNode* r, myNode* l) : E(e), left(nullptr), right(r){};
myNode* myNode::getLeft(myNode* node) { return node->left; }
myNode* myNode::getRight(myNode* node) { return node->right; }
void myNode::setLeft(myNode* node, myNode* l) {
  assert(node->left == nullptr);
  node->left = l;
}
void myNode::setRight(myNode* node, myNode* r) {
  assert(node->right == nullptr);
  node->right = r;
}
int myNode::getValue() { return E; }
